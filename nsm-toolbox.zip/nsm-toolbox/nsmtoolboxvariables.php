<?php
	global $wpdb;
	$table_name = $wpdb->prefix.'nsmvariables';
	$wpdb->query('CREATE TABLE IF NOT EXISTS '.$table_name.' (variable_id int(11) NOT NULL AUTO_INCREMENT, variable_name varchar(500) NOT NULL, variable_value varchar(5000) DEFAULT NULL,PRIMARY KEY (variable_id))');
	if(isset($_POST["btnUpdateVariables"]))
	{
		$values = array();
		$place_holders = array();
		$query = "INSERT INTO ".$table_name." (variable_name, variable_value) VALUES ";
		for($i=0; $i<count($_REQUEST["txtVariableName"]);$i++) 
		{
			if(!empty($_REQUEST["txtVariableName"][$i]))
			{
				array_push($values, $_REQUEST["txtVariableName"][$i], $_REQUEST["txtVariableValue"][$i]);
     			$place_holders[] = "('%s', '%s')" ;
			}
		}
		if(!empty($values))
		{
			$query .= implode(', ', $place_holders);

			$wpdb->query( $wpdb->prepare("$query ", $values));
		}
	}
	if(isset($_POST["btnImportFile"]))
	{
		$data = file_get_contents($_FILES['importfile']['tmp_name']);
		$data = json_decode($data); 
		$values = array();
		$place_holders = array();
		$query = "INSERT INTO ".$table_name." (variable_name, variable_value) VALUES ";
		foreach ($data as $key => $value) 
		{
			array_push($values, $key, $value);
     		$place_holders[] = "('%s', '%s')" ;
		}
		$query .= implode(', ', $place_holders);
		$wpdb->query( $wpdb->prepare("$query ", $values));
	}
	$Query = "SELECT variable_name, variable_value FROM ".$table_name;
	if(isset($_POST["btnSearch"]))
	{
		$Query .= " WHERE variable_name LIKE '%".$_POST["txtSearch"]."%'";
	}
	$myrows = $wpdb->get_results($Query);
?>
<div class="wrap">
	<h1>NSM Toolbox Variables</h1>
	<div>
		<form method="post" enctype="multipart/form-data">
			<table>
				<tbody id="VariableTable">
					<tr>
						<td>
							<input type="file" id="importfile" name="importfile" value="" class="regular-text" accept="application/json" >
						</td>
						<td>	
							<input type="submit" id="btnImportFile" name="btnImportFile" class="button" value="Upload JSON">
							<input type="submit" id="search-submit" class="button" value="Export JSON">
						</td>
					</tr>
					<tr>
						<td>
							<input type="search" id="txtSearch" name="txtSearch" value="<?= (isset($_REQUEST["txtSearch"]))?$_REQUEST["txtSearch"]:""; ?>" class="regular-text">
						</td>
						<td>
							<input type="submit" id="btnSearch" name="btnSearch" class="button" value="Search Variable">
						</td>
					</tr>
				<?php
					$index = 0;
					foreach ($myrows AS $variable) 
					{
				?>	
					<tr>
						<td>
							<input name="" type="text" value="<?= $variable->variable_name; ?>" class="regular-text">
							=
						</td>
						<td>
							<textarea class="regular-text" name=""><?= $variable->variable_value; ?></textarea>
						</td>
					</tr>
				<?php
					}
				?>	
					<tr <?= (isset($_POST["btnSearch"]))?"style='display:none'":"" ?>>
						<td>
							<input name="txtVariableName[]" type="text" value="" placeholder="Variable Name" class="regular-text">
							=
						</td>
						<td>
							<textarea class="regular-text" name="txtVariableValue[]"></textarea>
						</td>
					</tr>
				</tbody>
			</table>
			<p class="submit" <?= (isset($_POST["btnSearch"]))?"style='display:none'":"" ?>>
				<input type="button" name="btnAddMore" id="btnAddMore" class="button button-default" value="Add More Variable">
				<input type="submit" name="btnUpdateVariables" id="btnUpdateVariables" class="button button-primary" value="Update">				
			</p>
		</form>
	</div>
	
</div>
<script>
	jQuery("#btnAddMore").click(function(){
		jQuery( "#VariableTable" ).append( '<tr><td><input name="txtVariableName[]" type="text" value="" placeholder="Variable Name" class="regular-text"> = </td><td><textarea class="regular-text" name="txtVariableValue[]"></textarea></td></tr>' );
	});
</script>