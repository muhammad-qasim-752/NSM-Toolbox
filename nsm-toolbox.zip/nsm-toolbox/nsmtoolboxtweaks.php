<?php
	global $wpdb;
	$remove_h1 = get_option("remove_h1");
	$table_name = $wpdb->prefix.'options';
	if(isset($_REQUEST["btnRemoveTag"]))
	{
		if(!isset($remove_h1) || empty($remove_h1))
		{
			$wpdb->insert($table_name,
			array('option_name' => 'remove_h1','option_value'=>$_REQUEST["cboRemoveh1"]),
			array('%s','%s'));
		}
		else
		{
			$wpdb->update($table_name, array('option_value'=>$_REQUEST["cboRemoveh1"]), array('option_name'=>'remove_h1'));
		}
		$remove_h1 = $_REQUEST["cboRemoveh1"];
	}
?>
<div class="wrap">
	<h1>NSM Toolbox Tweaks</h1>
	<form method="post">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><label for="cboRemoveh1">Remove H1</label></th>
					<td>
						<select id="cboRemoveh1" name="cboRemoveh1">
							<option value="1">Do nothing</option>
							<option value="2" <?= (isset($remove_h1) && $remove_h1 == 2)?"SELECTED":""; ?>>Remove h1</option>
						</select>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="submit">
			<input type="submit" name="btnRemoveTag" id="btnRemoveTag" class="button button-primary" value="Save Changes">
		</p>
	</form>
</div>