<?php
/*
Plugin Name: NSM Toolbox
Description: NSM Toolbox
Author: NSM
Author URI: neverstopmedia.com
Version: 0.1


*/

function nsmToolbox()
{
	add_menu_page("NSM Toolbox","NSM Toolbox","manage_options","nsmtoolbox","nsmToolboxTweaks");
	add_submenu_page('nsmtoolbox', 'NSM Toolbox - Tweaks', 'Tweaks', 'manage_options', 'nsmtoolboxtweaks', 'nsmToolboxTweaks' );
	add_submenu_page('nsmtoolbox', 'NSM Toolbox - Variables', 'Variables', 'manage_options', 'nsmtoolboxvariables', 'nsmToolboxVariables' );

}
add_action("admin_menu","nsmToolbox");

function nsmToolboxTweaks()
{
	include_once("nsmtoolboxtweaks.php");
}
function nsmToolboxVariables()
{
	include_once("nsmtoolboxvariables.php");
}
add_filter('the_title', 'new_title');
function new_title($title) {
	if(is_single())
	{
		global $post;	
		if(isset($post) && isset($post->ID))
		{
			$remove_h1 = get_option("remove_h1");
			if($remove_h1 == "2")
				$title = "";
		}
	}
    return $title;
}

function nsmToolboxGlobalVariables() 
{
	global $wpdb;
	global $cgv;
	$cgv = array();
	$table_name = $wpdb->prefix.'nsmvariables';
	$myrows = $wpdb->get_results( "SELECT variable_name, variable_value FROM ".$table_name );
	foreach ($myrows as $variables) 
	{
		$cgv[$variables->variable_name] = $variables->variable_value;
	}
}
add_action( 'after_setup_theme', 'nsmToolboxGlobalVariables' );


add_action('template_redirect','yoursite_template_redirect');
function yoursite_template_redirect() {
  if ($_SERVER['REQUEST_URI']=='/downloads/data.csv') {
    header("Content-type: application/x-msdownload",true,200);
    header("Content-Disposition: attachment; filename=data.csv");
    header("Pragma: no-cache");
    header("Expires: 0");
    echo 'data';
    exit();
  }
}